#include "bst.h"

int main()
{
    avgdepth();
}